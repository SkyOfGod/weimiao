package com.sjzx.mapper;

import com.sjzx.entity.TargetCategory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 指标类型明细 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2020-11-27
 */
public interface TargetCategoryMapper extends BaseMapper<TargetCategory> {

}
