package com.sjzx.mapper;

import com.sjzx.entity.HotType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 热点类型 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-02-04
 */
public interface HotTypeMapper extends BaseMapper<HotType> {

}
