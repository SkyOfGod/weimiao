package com.sjzx.mapper;

import com.sjzx.entity.Fund;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 基金表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-08-20
 */
public interface FundMapper extends BaseMapper<Fund> {

}
