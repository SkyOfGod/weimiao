package com.sjzx.controller;


import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 公司行业类型表 前端控制器
 * </p>
 *
 * @author 
 * @since 2020-12-02
 */
@RestController
@Api(tags = "公司行业类型管理接口")
@RequestMapping("/companyType")
public class CompanyTypeController {

}
